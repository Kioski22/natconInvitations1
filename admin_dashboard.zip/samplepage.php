<!DOCTYPE html>
<html lang="en" class="h-100">
  <head>
    <meta charset="UTF-8">
    <title>Test Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
      html, body {
        height: 100%;
        background-color: #d0f0ff !important;
      }
    </style>
  </head>
  <body>
    <div class="d-flex justify-content-center align-items-center h-100">
      <h1 class="text-dark">Hello World</h1>
    </div>
  </body>
</html>
